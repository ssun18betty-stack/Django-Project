"""Defines URL patterns for budget_app."""
from django.urls import path
from . import views

app_name = 'budget_app'

urlpatterns = [
    # Home page
    path('', views.index, name='index'),

    # Page for viewing all transactions
    path('transactions/', views.transactions, name='transactions'),

    # Page for viewing a single transaction and its entries
    path('transactions/<int:transaction_id>/', views.transaction, name='transaction'),
]
