from django.db import models

class Transaction(models.Model):
    """A transaction type"""
    Transactions = models.CharField(max_length=200)
    date_added = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        """Return a string representation of the model."""
        return self.Transactions
    
class Entry(models.Model):
    """Something specific learned about a transaction"""
    transaction = models.ForeignKey(Transaction, on_delete=models.CASCADE)
    merchant = models.CharField(max_length=200)
    description = models.TextField()
    transition_amount = models.DecimalField(max_digits=10, decimal_places=2)
    date_added = models.DateTimeField(auto_now_add=True)

    class Meta: 
        verbose_name_plural = 'entries'

    def __str__(self):
        """Return a string representation of the model."""
        return str(self.description[:50]) + "..."



    