from django.shortcuts import render

from .models import Transaction

def index(request):
    """The home page for Budget App."""
    return render(request, 'budget_app/index.html')

def transactions(request):
    """Show all transactions."""
    transactions = Transaction.objects.order_by('-date_added')
    context = {'transactions': transactions}
    return render(request, 'budget_app/transactions.html', context)

def transaction(request, transaction_id):
    """Show a single transaction and its entries."""
    transaction = Transaction.objects.get(id=transaction_id)
    entries = transaction.entry_set.order_by('-date_added')
    context = {'transaction': transaction, 'entries': entries}
    return render(request, 'budget_app/transaction.html', context)