from django import forms

from .models import Transaction, Entry

class EntryForm(forms.ModelForm):
    class Meta:
        model = Entry
        fields = ['merchant', 'description', 'transition_amount']

class TranactionForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = ['Transactions']
        widgets = {'Transactions': forms.Textarea(attrs={'cols': 80, 'rows': 3})}
        
