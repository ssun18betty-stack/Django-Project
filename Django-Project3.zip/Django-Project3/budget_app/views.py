from django.shortcuts import render, redirect

from .models import Transaction, Entry
from .forms import EntryForm
import plotly.express as px
import pandas as pd

def index(request):
    """The home page for Budget App."""
    return render(request, 'budget_app/index.html')

def transactions(request):
    """Show all transactions."""
    transactions = Transaction.objects.order_by('-date_added')
    context = {'transactions': transactions}
    return render(request, 'budget_app/transactions.html', context)

def transaction(request, transaction_id):
    """Show a single transaction and its entries."""
    transaction = Transaction.objects.get(id=transaction_id)
    entries = transaction.entry_set.order_by('-date_added')
    context = {'transaction': transaction, 'entries': entries}
    return render(request, 'budget_app/transaction.html', context)

def new_entry(request, transaction_id):
    """Add a new entry"""
    transaction = Transaction.objects.get(id=transaction_id)

    if request.method != 'POST':
        form = EntryForm()
    else:
        form = EntryForm(data=request.POST)
        if form.is_valid():
            new_entry = form.save(commit=False)
            new_entry.transaction = transaction   
            new_entry.save()
            return redirect('budget_app:transaction', transaction_id)

    context = {'form': form, 'transaction': transaction}
    return render(request, 'budget_app/new_entry.html', context)


def bar_chart(request):
    transactions = Transaction.objects.all()
    transaction_amounts = [(transaction.Transactions, sum(entry.transition_amount for entry in transaction.entry_set.all()))for transaction in transactions]
    df = pd.DataFrame(transaction_amounts, columns=['Transaction Type', 'Total Amount'])
    df['Transaction Type'] = pd.Categorical(df['Transaction Type'],categories=['Credit','Debit'], ordered=True)
    df = df.sort_values(by='Transaction Type', ascending=False)
    fig = px.bar(df, x='Transaction Type', y='Total Amount', color='Transaction Type',title='Credit/Debit')
    chart_html = fig.to_html(full_html=False)
    return render(request, 'budget_app/bar_chart.html', {'chart_html': chart_html})

def edit_entry(request, entry_id):
    """Edit an existing entry"""
    entry = Entry.objects.get(id=entry_id)
    if request.method != 'POST':
         # Initial request; pre-fill form with the current entry.
         form = EntryForm(instance=entry)
    else:
         # POST data submitted; process data.
         form = EntryForm(instance=entry, data=request.POST)
         if form.is_valid():
              form.save()
              return redirect('budget_app:transaction', transaction_id=entry.transaction.id)
    context = {'entry': entry, 'form': form}
    return render(request, 'budget_app/edit_entry.html', context)

def delete_entry(request, entry_id):
    entry = Entry.objects.get(id=entry_id)
    transaction = entry.transaction
    entry.delete()
    return redirect('budget_app:transaction', transaction_id=transaction.id)

def delete_transaction(request, transaction_id):
    transaction = Transaction.objects.get(id=transaction_id)
    transaction.delete()
    return redirect('budget_app:transactions')

