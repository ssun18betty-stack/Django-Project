"""Defines URL patterns for budget_app."""
from django.urls import path
from . import views

app_name = 'budget_app'

urlpatterns = [
    # Home page
    path('', views.index, name='index'),

    # Page for viewing all transactions
    path('transactions/', views.transactions, name='transactions'),

    # Page for viewing a single transaction and its entries
    path('transactions/<int:transaction_id>/', views.transaction, name='transaction'),

    # Page for adding a new entry
    path('transactions/<int:transaction_id>/new_entry/',views.new_entry,name='new_entry'),

    # Page for displaying a bar chart
    path('bar_chart/', views.bar_chart, name='bar_chart'),

    # Page for adding a new entry
    path('new_entry/<int:transaction_id>/', views.new_entry, name='new_entry'),

    # Page for edditing an existing entry
    path('edit_entry/<int:entry_id>/', views.edit_entry, name='edit_entry'),

    # Page for deleting an exsiting entry
    path('delete_entry/<int:entry_id>/', views.delete_entry, name='delete_entry'),

    # Page for adding a new transaction
    path('delete_transaction/<int:transaction_id>/', views.delete_transaction, name='delete_transaction'),
]

